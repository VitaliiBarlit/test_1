from django.apps import AppConfig


class RecomendationsConfig(AppConfig):
    name = 'recomendations'
