from django.apps import AppConfig


class GalleriesConfig(AppConfig):
    name = 'galleries'
