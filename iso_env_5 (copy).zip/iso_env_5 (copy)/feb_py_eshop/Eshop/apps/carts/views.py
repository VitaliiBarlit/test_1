from django.http import HttpResponse
from apps.carts.models import Cart, CartItem
from rest_framework import generics, pagination
from django.shortcuts import get_object_or_404
from apps.carts.serializers import CartSerializer, CartItemSerializer
from apps.carts.permissions import IsOwnerOrReadOnly, CartPermissions, CartItemPermissions
from apps.carts.filters import CartFilter, CartItemFilter
from rest_framework.response import Response

def index(request):
    cart_list = CartItem.objects.all()
    return HttpResponse(', '.join([c.CartItem for c in cart_list]))


class CartList(generics.ListCreateAPIView):
    serializer_class = CartSerializer
    pagination_class = pagination.LimitOffsetPagination
    filter_class = CartFilter
    pagination_class.default_limit = 5
    pagination_class.max_limit = 25
    permission_classes = [IsOwnerOrReadOnly, CartPermissions, ]
    
    def get_queryset(self):
        return Cart.objects.filter(user=self.request.user)

class CartDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = CartSerializer
    pagination_class = pagination.LimitOffsetPagination
    pagination_class.default_limit = 5
    pagination_class.max_limit = 25
    permission_classes = [IsOwnerOrReadOnly, CartPermissions, ]

    def get_object(self):
        obj = get_object_or_404(Cart, 
                                user=self.request.user, 
                                pk=self.kwargs.get('cart_id'))
        return obj
    
class CartItemCreate(generics.CreateAPIView):
    queryset = CartItem.objects.all()
    serializer_class = CartItemSerializer
    permission_classes = [IsOwnerOrReadOnly, CartItemPermissions, ]
    
    # def perform_create(self, request):
    #     cartitem = get_object_or_404(CartItem, id=self.request.data.get('cartitem_id'))
    #     return Response(status=204)
    # model = CartItem

    # def create(self, request, *args, **kwargs):
    #     response = super(CartItemCreate, self).create(request, *args, **kwargs)
    #     token, created = Token.objects.get_or_create(user=serializer.instance)
    #     response.status = status.HTTP_200_OK
    #     response.data = {'token': token.key}
    #     return response
class CartItemList(generics.ListCreateAPIView):
    serializer_class = CartItemSerializer
    pagination_class = pagination.LimitOffsetPagination
    filter_class = CartItemFilter
    pagination_class.default_limit = 5
    pagination_class.max_limit = 25
    permission_classes = [IsOwnerOrReadOnly, CartItemPermissions, ]
    
    def get_queryset(self):
        return CartItem.objects.filter(user=self.request.user)
    
    
class CartItemDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = CartItemSerializer
    pagination_class = pagination.LimitOffsetPagination
    pagination_class.default_limit = 5
    pagination_class.max_limit = 25
    permission_classes = [IsOwnerOrReadOnly, CartItemPermissions, ]
    
    def get_object(self):
        obj = get_object_or_404(CartItem, 
                                user=self.request.user, 
                                pk=self.kwargs.get('user_id'))
        return obj