from django.contrib import admin
from apps.carts.models import Cart, CartItem

class CartAdmin(admin.ModelAdmin):

    class Meta:
        model = Cart

    fieldsets = [('Опис', {'fields': ['user',  ]}),]         
    list_display = ['id', 'user', 'not_empty', 'created_on', 
                    'updated_on', 'created_by', 
                  'total_price', 'cart_list', 'not_available']

class CartItemAdmin(admin.ModelAdmin):

    class Meta:
        model = CartItem

    fieldsets = [('Опис',  {'fields': ['product', 'stock_count', 'quantity', 'cart',]}),]
    list_display = ['id', 'user', 'cart', 'product', 'quantity', 
                    'created_on', 'updated_on', 'created_by', 
                    'cart_item_status', 'stock_count']
    readonly_fields = ['user', 'stock_count',]
    list_editable = ['quantity']


# admin.site.unregister(Cart)
admin.site.register(Cart, CartAdmin)
# admin.site.unregister(CartItem)
admin.site.register(CartItem, CartItemAdmin)

