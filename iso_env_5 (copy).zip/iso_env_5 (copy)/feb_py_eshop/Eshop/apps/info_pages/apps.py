from django.apps import AppConfig


class InfoPagesConfig(AppConfig):
    name = 'info_pages'
