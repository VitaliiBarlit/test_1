from django.apps import AppConfig


class ShipmentsConfig(AppConfig):
    name = 'shipments'
